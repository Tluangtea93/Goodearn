# TON Earn Telegram Mini App

## ✅ Features
- Monetag ads (3 integrated)
- TON wallet withdraw support (via Google Form)
- Persistent balance (localStorage)
- Telegram Mini App compatible

## 🚀 Hosting
1. Upload `index.html` to GitHub.
2. Enable GitHub Pages.
3. Use URL as your Telegram Mini App link.

## ⚙️ Withdraw Setup
Replace `formURL` and `entry.XXXXX` values with your Google Form link and field IDs.
